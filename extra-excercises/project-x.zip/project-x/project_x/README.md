### The quest for Joey's egg's!

#### The story line

After Judis Andris had fled/banished to Emulandia, he moved to the old city: Amaru. 
This city has been an important city since 7138 BC (before Christ) after Judis reformed the city to its former glory he came across ancient papyrus scrolls. 
These reels looked like some sort of treasure map. He has decided to send one of his bodyguards out and complete this quest…

## License

NO licences needed.