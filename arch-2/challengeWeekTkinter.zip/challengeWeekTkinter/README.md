#### For this code you need to run a couple of things:
### Note: If you are on a Windows PC, use pip instead of pip3
---
For installing the sense hat library
```
$ pip3 install sense_hat
```

For installing JSON
```
$ pip3 install json
```

For installing the Tkinter GUI library
```
$ pip3 install tk
```

For installing the Tkinter GUI library
```
$ pip3 install requests
```

For installing PrettyTable
```
$ pip3 install prettytable
```

For installing Matplotlib
```
$ pip3 install matplotlib
```
