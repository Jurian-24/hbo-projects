class HighRisk:
    def __init__(self):
        self.banaan = 'Hello world'

    def test(self):
        print(self.banaan)
