#### Installations

```
$ pip3 install python-dotenv
```

Or if you are using python2

```
$ pip install python-dotenv
```
